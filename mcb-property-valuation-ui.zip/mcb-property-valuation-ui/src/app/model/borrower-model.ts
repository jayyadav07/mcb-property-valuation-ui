export class Borrower{
    name!: string;
    customerNumber!: string;
    contactNumber!: string;
    email!: string;
    address!: string;
}
