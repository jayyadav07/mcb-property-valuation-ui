import { DropdownData } from "./dropdown-data-model";

export class Facilty{
    catagory!: String;
    purpose!: String;
    term!: String;
    amount!: String;
    type!: DropdownData;
    ccy!: DropdownData;
}