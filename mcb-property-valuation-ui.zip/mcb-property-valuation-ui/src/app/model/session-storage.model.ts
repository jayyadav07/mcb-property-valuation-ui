export class SessionStorageModel {
    accessToken: string = '';
    userId: number = 0;
    username: string = '';
    refreshToken: string = '';
    roleId: number = 0;
    businessUnit: string = '';
    refNo:number = 0;
}