import { DropdownData } from "./dropdown-data-model"

export class Document{
    type!: DropdownData;
    document!: String;
}