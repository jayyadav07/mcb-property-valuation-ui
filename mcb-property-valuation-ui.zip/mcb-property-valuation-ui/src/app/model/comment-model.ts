export class Comment{
    comments!: string;
    createdDates!: string;
}