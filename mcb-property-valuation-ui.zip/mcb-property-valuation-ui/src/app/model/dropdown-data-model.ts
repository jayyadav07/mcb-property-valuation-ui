export class DropdownData{
    id!: number;
    name!: String;
}